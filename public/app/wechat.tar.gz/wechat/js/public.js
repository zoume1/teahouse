document.write('<script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>');
document.write('<script src="../js/plugin/layer.js" type="text/javascript" charset="utf-8"></script>');;
(function() {
  window.myFun = {
    baseUrl: 'https://www.zhihuichacang.com/',
    userid: sessionStorage.getItem('userid'),
    invitation: sessionStorage.getItem('invitation'),
    no_mention: sessionStorage.getItem('no_mention'),
    loading: null,
    // 开启加载动画
    openLoading: function() {
      myFun.loading = layer.open({
        type: 2,
        content: '数据加载中',
        shadeClose: false,
        time: 5
      });
    },
    // 关闭加载动画
    closeLoading: function() {
      layer.close(myFun.loading)
    },
    // 请求超时
    timeout: function() {
      layer.open({
        content: '请求超时，请检查您的网络！',
        skin: 'msg',
        time: 2,
      });
    },
    // 提示信息
    layerMsg: function(msg) {
      layer.open({
        content: msg,
        skin: 'msg',
        time: 2,
      });
    },
    myAjax: function(url, params, type, callback) {
      $.ajax({
        url: myFun.baseUrl + url,
        data: params,
        dataType: 'json',
        type: type,
        timeout: 5000,
        success: function(data) {
          callback(data);
        },
        complete: function(data, status) {
          if (status === 'timeout') {
            myFun.timeout()
          }
        }
      })
    },
    myFormAjax: function(url, params, callback) {
      $.ajax({
        url: myFun.baseUrl + url,
        type: 'POST',
        cache: false, //上传文件不需要缓存
        data: params,
        processData: false, // 告诉jQuery不要去处理发送的数据
        contentType: false, // 告诉jQuery不要去设置Content-Type请求头
        success: function(data) {
          callback(data);
        }
      })
    },
    //时间转换
    formatDate: function(inputTime) {
      var date = new Date(inputTime * 1000);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      var second = date.getSeconds();
      minute = minute < 10 ? ('0' + minute) : minute;
      second = second < 10 ? ('0' + second) : second;
      return y + "年" + m + "月" + d + "日";
    },
    countdown: function($el, msNum, timeFormat) {
      console.log($el)
      var text = $el.data("text") || $el.text(),
        timer = 0;
      $el.prop("disabled", true).addClass("disabled")
        .on("bc.clear", function() {
          clearTime();
        });;
      (function countdown() {
        var time = showTime(msNum)[timeFormat];
        $el.text(time + '后失效');
        if (msNum <= 0) {
          msNum = 0;
          clearTime();
        } else {
          msNum -= 1000;
          timer = setTimeout(arguments.callee, 1000);
        }
      }())

      function clearTime() {
        clearTimeout(timer);
        $el.prop("disabled", false).removeClass("disabled").text(text);
      }

      function showTime(ms) {
        var d = Math.floor(ms / 1000 / 60 / 60 / 24),
          h = Math.floor(ms / 1000 / 60 / 60 % 24),
          m = Math.floor(ms / 1000 / 60 % 60),
          s = Math.floor(ms / 1000 % 60),
          ss = Math.floor(ms / 1000);
        return {
          d: d + "天",
          h: h + "小时",
          m: m + "分",
          ss: ss + "秒",
          "d:h:m:s": d + "天" + h + "小时" + m + "分" + s + "秒",
          "h:m:s": h + "小时" + m + "分" + s + "秒",
          "m:s": m + "分" + s + "秒"
        };
      }
      return this;
    },
    // 转换时间戳
    timetrans: function(date) {
      var date = new Date(date * 1000); //如果date为13位不需要乘1000
      var Y = date.getFullYear() + '-';
      var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
      var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
      var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
      var s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
      return Y + M + D;
    },
    // 手机号打星号
    phonetrans: function(data) {
      return data.replace(/^(\d{3})\d{4}(\d+)/, "$1****$2")
    },
    // 获取验证码
    getCode: function(params, callback) {
      myFun.myAjax('rec/code', params, 'GET', callback);
    },
    // 用户注册
    userRegister: function(params, callback) {
      myFun.myAjax('rec/register', params, 'POST', callback);
    },
    // 用户登录
    userLogin: function(params, callback) {
      myFun.myAjax('rec/login', params, 'POST', callback);
    },
    // 忘记密码
    userForget: function(params, callback) {
      myFun.myAjax('rec/forget', params, 'POST', callback);
    },
    // 我的店铺
    userIndex: function(params, callback) {
      myFun.myAjax('rec/user_store', params, 'POST', callback);
    },
    // 更换手机
    changePhone: function(params, callback) {
      myFun.myAjax('rec/edit_phone', params, 'POST', callback);
    },
    // 我的店铺
    getAllStore: function(params, callback) {
      myFun.myAjax('store_all_data', params, 'POST', callback);
    },
    // 图片上传
    uploadImg: function(params, callback) {
      myFun.myFormAjax('/rec/upload', params, callback);
    },
    // 创建店铺
    addStore: function(params, callback) {
      myFun.myAjax('sj_store_add', params, 'POST', callback);
    },
    // 套餐類型
    classify: function(params, callback) {
      myFun.myAjax('rec/classify', params, 'POST', callback);
    },
    // 获取发票地址
    getAddress: function(params, callback) {
      myFun.myAjax('rec/in_address', params, 'POST', callback);
    },
    // 创建订单
    getOrder: function(params, callback) {
      myFun.myAjax('rec/meal_order', params, 'POST', callback);
    },
    // 分销佣金
    getFxyj: function(params, callback) {
      myFun.myAjax('rec/user_commission', params, 'POST', callback);
    },
    // 套餐再次支付
    repay: function(params, callback) {
      myFun.myAjax('rec/shop_wxpay', params, 'POST', callback);
    },
    // 提现
    withDraw: function(params, callback) {
      myFun.myAjax('rec/cash_with', params, 'POST', callback);
    },
    // 提现记录
    withdrawRecord: function(params, callback) {
      myFun.myAjax('rec/record_with', params, 'POST', callback);
    },
    // 获取城市
    getCity: function(params, callback) {
      myFun.myAjax('city/chooseRank', params, 'POST', callback);
    },
    // 申请城市代理人
    applyCity: function(params, callback) {
      myFun.myFormAjax('/city/apply_register', params, callback);
    },
    // 城市获取验证码
    sendPhoneCode: function(params, callback) {
      myFun.myAjax('sendIdentiFyingCode', params, 'POST', callback);
    },
    getQRcode: function(params, callback) {
      myFun.myAjax('rec/qr_code', params, 'POST', callback);
    },
    // 城市合伙人登录
    cityLogin: function(params, callback) {
      myFun.myAjax('city/apply_watchat_login', params, 'POST', callback);
    },
    //合伙人付款后页面
    payAfter: function(params, callback) {
      myFun.myAjax('city/WeiChatCityServerShow', params, 'POST', callback);
    },
    //合伙人微信付款
    wechatPay: function(params, callback) {
      myFun.myAjax('city/city_WhatChatPay', params, 'POST', callback);
    },
    // 合伙人 保底佣金总额
    getBdyj: function(params, callback) {
      myFun.myAjax('city/WeiChatCityCommissionShow', params, 'POST', callback);
    },
    //合伙人未付款订单
    cityOrder: function(params, callback) {
      myFun.myAjax('city/city_order_index', params, 'POST', callback);
    },
    //获取城市合伙人地址
    cityAddress: function(params, callback) {
      myFun.myAjax('city/mailing_address', params, 'POST', callback);
    },
    //获取城市合伙人开发票
    cityKp: function(params, callback) {
      myFun.myAjax('city/cityOrderReceipt', params, 'POST', callback);
    },
    // 合伙人 达标佣金总额
    getDbyj: function(params, callback) {
      myFun.myAjax('city/WeiChatCityReachCommissionShow', params, 'POST', callback);
    },
    // 合伙人 城市总计商户
    getCszjsh: function(params, callback) {
      myFun.myAjax('city/WeiChatCityAccumulativeShow', params, 'POST', callback);
    },
    // 合伙人 我邀请的商户
    getYqsh: function(params, callback) {
      myFun.myAjax('city/WeiChatCityMyinviteShow', params, 'POST', callback);
    },
    // 合伙人 市场反馈 评论
    sendDiscuss: function(params, callback) {
      myFun.myAjax('city/market_feedback', params, 'POST', callback);
    },
    // 合伙人 市场反馈 官方回复数量
    getMarketNum: function(params, callback) {
      myFun.myAjax('city/admin_market_feedback_number', params, 'POST', callback);
    },
    // 合伙人 市场反馈 详情
    getFeedbackDet: function(params, callback) {
      myFun.myAjax('city/admin_market_feedback', params, 'POST', callback);
    },
    // 合伙人 所有城市合伙人显示
    getAllpartner: function(params, callback) {
      myFun.myAjax('city/allCityCobber', params, 'POST', callback);
    },
    // 合伙人 评分
    scorePartner: function(params, callback) {
      myFun.myAjax('city/WeiChatStoreComment', params, 'POST', callback);
    },
  }
})()
