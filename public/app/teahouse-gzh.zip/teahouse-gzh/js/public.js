document.write('<script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>');
document.write('<script src="../js/plugin/layer.js" type="text/javascript" charset="utf-8"></script>');
;(function() {
  window.myFun = {
    baseUrl: 'https://www.zhihuichacang.com/',
    userid: sessionStorage.getItem('userid'),
    loading: null,
    // 开启加载动画
    openLoading: function() {
      myFun.loading = layer.open({
        type: 2,
        content: '数据加载中',
        shadeClose: false,
        time: 5
      });
    },
    // 关闭加载动画
    closeLoading: function() {
      layer.close(myFun.loading)
    },
    // 请求超时
    timeout: function() {
      layer.open({
        content: '请求超时，请检查您的网络！',
        skin: 'msg',
        time: 2,
      });
    },
    // 提示信息
    layerMsg: function(msg) {
      layer.open({
        content: msg,
        skin: 'msg',
        time: 2,
      });
    },
    myAjax: function(url, params, type, callback) {
      $.ajax({
        url: myFun.baseUrl + url,
        data: params,
        dataType: 'json',
        type: type,
        timeout: 5000,
        success: function(data) {
          callback(data);
        },
        complete: function(data, status) {
          if (status === 'timeout') {
            myFun.timeout()
          }
        }
      })
    },
    myFormAjax: function(url, params, callback) {
      $.ajax({
        url: myFun.baseUrl + url,
        type: 'POST',
        cache: false, //上传文件不需要缓存
        data: params,
        processData: false, // 告诉jQuery不要去处理发送的数据
        contentType: false, // 告诉jQuery不要去设置Content-Type请求头
        success: function(data) {
          callback(data);
        }
      })
    },
    countdown: function($el, msNum, timeFormat) {
      console.log($el)
      var text = $el.data("text") || $el.text(),
        timer = 0;
      $el.prop("disabled", true).addClass("disabled")
        .on("bc.clear", function() {
          clearTime();
        });;
      (function countdown() {
        var time = showTime(msNum)[timeFormat];
        $el.text(time + '后失效');
        if (msNum <= 0) {
          msNum = 0;
          clearTime();
        } else {
          msNum -= 1000;
          timer = setTimeout(arguments.callee, 1000);
        }
      }())

      function clearTime() {
        clearTimeout(timer);
        $el.prop("disabled", false).removeClass("disabled").text(text);
      }

      function showTime(ms) {
        var d = Math.floor(ms / 1000 / 60 / 60 / 24),
          h = Math.floor(ms / 1000 / 60 / 60 % 24),
          m = Math.floor(ms / 1000 / 60 % 60),
          s = Math.floor(ms / 1000 % 60),
          ss = Math.floor(ms / 1000);
        return {
          d: d + "天",
          h: h + "小时",
          m: m + "分",
          ss: ss + "秒",
          "d:h:m:s": d + "天" + h + "小时" + m + "分" + s + "秒",
          "h:m:s": h + "小时" + m + "分" + s + "秒",
          "m:s": m + "分" + s + "秒"
        };
      }
      return this;
    },
    // 获取验证码
    getCode: function(params, callback) {
      myFun.myAjax('rec/code', params, 'GET', callback);
    },
    // 用户注册
    userRegister: function(params, callback) {
      myFun.myAjax('rec/register', params, 'POST', callback);
    },
    // 用户登录
    userLogin: function(params, callback) {
      myFun.myAjax('rec/login', params, 'POST', callback);
    },
    // 忘记密码
    userForget: function(params, callback) {
      myFun.myAjax('rec/forget', params, 'POST', callback);
    },
    // 我的店铺
    userIndex: function(params, callback) {
      myFun.myAjax('rec/user_store', params, 'POST', callback);
    },
    // 更换手机
    changePhone: function(params, callback) {
      myFun.myAjax('rec/edit_phone', params, 'POST', callback);
    },
    // 我的店铺
    getAllStore: function(params, callback) {
      myFun.myAjax('store_all_data', params, 'POST', callback);
    },
    // 图片上传
    uploadImg: function(params, callback) {
      myFun.myFormAjax('/rec/upload', params, callback);
    },
    // 创建店铺
    addStore: function(params, callback) {
      myFun.myAjax('store_add', params, 'POST', callback);
    },
    // 套餐類型
    classify: function(params, callback) {
      myFun.myAjax('rec/classify', params, 'POST', callback);
    },
    // 获取发票地址
    getAddress: function(params, callback) {
      myFun.myAjax('rec/in_address', params, 'POST', callback);
    },
    // 创建订单
    getOrder: function(params, callback) {
      myFun.myAjax('rec/meal_order', params, 'POST', callback);
    }
  }
})()
