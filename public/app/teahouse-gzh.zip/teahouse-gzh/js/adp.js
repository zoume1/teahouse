(function() {
  var html = document.documentElement;

  function onWindowResize() {
    html.setAttribute('style', 'font-size: ' + html.getBoundingClientRect().width / 7.5 + 'px!important;')
    // html.style.fontSize = html.getBoundingClientRect().width / 7.5 + 'px';
  }

  window.addEventListener('resize', onWindowResize);
  onWindowResize();
})();
